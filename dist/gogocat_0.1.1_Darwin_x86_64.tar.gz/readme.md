# GoGoCat
pipe CLI utility for prettifying output.

## Use
```cat main.go | docker run -i rogueelephant/gogocat```


## Example
_(Assuming you have cloned the directory and are in the top folder context)_
```cat main.go | gogocat```

```cat main.go | docker run -i gogocat```

![](readme.gif)